from .vbvarsel import main
from .global_parameters import *

__version__ = "0.0.1"
__authors__ = ["Paul Kirk", "Emma Prevot", "Rory Toogood", "Filippo Pagani", "Alan Nardo"]